const url = //"http://13.50.5.140:3003";
// "http://localhost:3003";
"https://api.society-synergy.nl";
const hosturl = "https://society-synergy.netlify.app";
const hosturl2 = "https://society-synergy.one";
export default url;