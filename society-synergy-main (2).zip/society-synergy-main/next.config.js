/** @type {import('next').NextConfig} */
const nextConfig = {
    // reactStrictMode: false,
    // staticPageGenerationTimeout: 300,
}

module.exports = nextConfig
